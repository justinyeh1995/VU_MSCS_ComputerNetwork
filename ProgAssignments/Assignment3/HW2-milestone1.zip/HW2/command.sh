h2 python3 grocery_server.py &
h3 python3 health_server.py &
h1 python3 refrigerator.py -g 10.0.0.2 -s 10.0.0.3 
